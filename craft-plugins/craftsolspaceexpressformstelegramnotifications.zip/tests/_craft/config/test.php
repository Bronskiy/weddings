<?php

use craft\test\TestSetup;

return TestSetup::createTestCraftObjectConfig();
