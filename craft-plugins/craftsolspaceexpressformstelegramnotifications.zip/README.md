# Craft Solspace Express Forms Telegram Notifications plugin for Craft CMS 3.x

Notifications to Telegram group via bot for Craft Solspace Express Forms Telegram 

![Screenshot](resources/img/plugin-logo.png)

## Requirements

This plugin requires Craft CMS 3.0.0-beta.23 or later.

## Installation

To install the plugin, follow these instructions.

1. Open your terminal and go to your Craft project:

        cd /path/to/project

2. Then tell Composer to load the plugin:

        composer require bronskiy/craft-solspace-express-forms-telegram-notifications

3. In the Control Panel, go to Settings → Plugins and click the “Install” button for Craft Solspace Express Forms Telegram Notifications.

## Craft Solspace Express Forms Telegram Notifications Overview

-Insert text here-

## Configuring Craft Solspace Express Forms Telegram Notifications

-Insert text here-

## Using Craft Solspace Express Forms Telegram Notifications

-Insert text here-

## Craft Solspace Express Forms Telegram Notifications Roadmap

Some things to do, and ideas for potential features:

* Release it

Brought to you by [Nikolay Bronskiy](https://www.bronskiy.com)
